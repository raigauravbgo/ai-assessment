# Problem C — Starter data

`job-description.txt` — the role we're hiring for.
`resumes/` — 20 candidate resumes received through our ATS.

Real-ish data: candidates vary widely in fit, formatting is inconsistent across files, some files have known quality issues (the kind of mixed bag you'd actually get from an ATS).

For v1, all resumes are .txt — we did not generate PDFs. The token-budget and prompt-injection considerations apply regardless of file format.
