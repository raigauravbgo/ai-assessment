# Problem A — Starter data

`accounts.csv` — ~200 overdue accounts exported from BGO's collections system.

Real-ish data: dates and formats vary, some fields are blank, currency formatting is inconsistent in places. Treat this as production data, not curated test data.
