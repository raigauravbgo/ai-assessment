# Problem D — Starter data

`responses.csv` — 160 anonymous pulse survey responses (80 employees × 2 questions).

Real-ish data: not all responses are substantive, some are blank, some are in mixed scripts. Anonymous — no identifying columns. Treat it as data straight out of the survey tool, not curated test data.
